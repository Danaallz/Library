package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginWindow extends JFrame {
    private JMenuBar menuBar;
    private JMenu Program;
    private JMenuItem exit;
    private JMenuItem AboutUs;
    private JMenuItem returnToMain;

    LoginWindow() {

        // font
        Font f = new Font("Serif", Font.BOLD, 35);
        Font g = new Font("Times New Roman", Font.BOLD, 14);

        // header
        JPanel heading;
        heading = new JPanel();
        heading.setBackground(new Color(0, 0, 0, 80));
        heading.setBounds(0, 0, 1100, 100);
        JLabel name = new JLabel("My Account");
        name.setForeground(Color.WHITE);
        name.setBounds(200, 25, 1100, 50);
        name.setFont(f);
        heading.add(name);

        // login panel
        JPanel login = new JPanel();
        login.setLayout(null);
        login.setSize(400, 350);
        login.setBackground(new Color(0, 0, 0, 60));
        login.setBounds(345, 175, 400, 350);

        JTextField username = new JTextField("Enter username..・", 10);
        username.setBounds(50, 50, 300, 50);
        username.setEditable(true);
        login.add(username);

        JPasswordField password = new JPasswordField("Enter password...", 20);
        password.setBounds(50, 150, 300, 50);
        login.add(password);

        JLabel LABEL = new JLabel("Don't have an account?");
        LABEL.setForeground(Color.WHITE);
        LABEL.setBounds(50, 216, 180, 50);
        LABEL.setFont(g);
        login.add(LABEL);
        JButton signup = new JButton("Sign Up");
        signup.setBounds(50, 250, 100, 50);
        signup.setBackground(new Color(160, 182, 45));
        signup.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                try {
                    Signin w = new Signin();
                } catch (IOException ex) {
                    Logger.getLogger(LoginWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                dispose();
            }
        });
        login.add(signup);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(250, 250, 100, 50);
        loginButton.setBackground(new Color(160, 182, 45));

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String enteredUsername = username.getText().trim();
                String enteredPassword = new String(password.getPassword()).trim();

                if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in both username and password.");
                    return;
                }

                boolean loginSuccess = false;

                try {
                    BufferedReader reader = new BufferedReader(new FileReader("userInfo.txt"));
                    String line;
                    String savedUsername = "";
                    String savedPassword = "";

                    while ((line = reader.readLine()) != null) {
                        if (line.startsWith("User Name:")) {
                            savedUsername = line.substring("User Name:".length()).trim();
                        } else if (line.startsWith("Password:")) {
                            savedPassword = line.substring("Password:".length()).trim();
                        }
                    }
                    reader.close();

                    if (enteredUsername.equals(savedUsername) && enteredPassword.equals(savedPassword)) {
                        loginSuccess = true;
                    }

                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error reading user info: " + ex.getMessage());
                }

                if (loginSuccess) {
                    try {
                        new BookSearcherWindow();
                    } catch (IOException | addException ex) {
                        JOptionPane.showMessageDialog(null, "Failed to open search window.");
                    }
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }
            }
        });

        login.add(loginButton);

        // frame
        setTitle("Book Recommendation System");
        setSize(1100, 700);
        setLayout(null);
        setLocationRelativeTo(null);
        // setLocation(400, 320);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        bulidMenuBar();

        // background
        ImageIcon background_image = new ImageIcon("background.jpeg");
        Image img = background_image.getImage();
        Image temp_img = img.getScaledInstance(1100, 700, Image.SCALE_SMOOTH);
        background_image = new ImageIcon(temp_img);
        JLabel background = new JLabel("", background_image, JLabel.CENTER);

        background.add(login);
        background.add(heading);
        background.setBounds(0, 0, 1100, 700);
        add(background);
        setVisible(true);

    }

    private void bulidMenuBar() {
        menuBar = new JMenuBar();
        bulidProgramMenu();
        menuBar.add(Program);
        setJMenuBar(menuBar);

    }

    private void bulidProgramMenu() {
        exit = new JMenuItem("Exit");
        exit.setMnemonic(KeyEvent.VK_X);
        exit.addActionListener(new ExitListener());

        AboutUs = new JMenuItem("About Us");
        AboutUs.setMnemonic(KeyEvent.VK_F);
        AboutUs.addActionListener(new AboutUsListener());

        returnToMain = new JMenuItem("Return to Main Page");
        returnToMain.setMnemonic(KeyEvent.VK_B);
        returnToMain.addActionListener(new returnToMainListener());

        Program = new JMenu("Program");
        Program.setMnemonic(KeyEvent.VK_R);
        Program.add(exit);
        Program.add(AboutUs);
        Program.add(returnToMain);
    }

    private class ExitListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    private class AboutUsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                AboutUs s = new AboutUs();
            } catch (Exception ex) {
                Logger.getLogger(LoginWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
            dispose();
        }
    }

    private class returnToMainListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            Book t = new Book();
            dispose();
        }
    }

    public static void main(String[] args) {
        new LoginWindow();
    }

}
