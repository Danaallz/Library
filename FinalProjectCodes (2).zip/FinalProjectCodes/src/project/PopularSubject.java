package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PopularSubject extends JFrame {
    private JMenuBar menuBar;
    private JMenu Program;
    private JMenu Profile;
    private JMenuItem exit;
    private JMenuItem AboutUs;
    private JMenuItem returnToMain;
    private JMenuItem Account;
    private Color originalColor;
    private JButton sub1 = new JButton("Time Travel");
    private JButton sub2 = new JButton("Adventure Stories");
    private JButton sub3 = new JButton("Science Fiction");
    private JButton sub4 = new JButton("Love Stories");
    private JButton sub5 = new JButton("Young Adult Fiction");
    private JButton sub6 = new JButton("Thrillers&Suspense");
    private JButton sub7 = new JButton("Fantasy Fiction");
    private JButton sub8 = new JButton("Romance");
    private JButton sub9 = new JButton("Dystopias");
    FileOutputStream file = new FileOutputStream("favoirteBook.dat");
    DataOutputStream output = new DataOutputStream(file);

    public PopularSubject() throws IOException {

        // header
        JPanel header = new JPanel();
        header.setBackground(new Color(0, 0, 0, 80));
        header.setBounds(0, 0, 1100, 100);
        JLabel name = new JLabel("Popular Subjects");
        name.setForeground(Color.WHITE);
        name.setBounds(200, 25, 1100, 50);
        name.setFont(new Font("Times New Roman", Font.BOLD, 35));
        header.add(name);

        // main panel
        JPanel main = new JPanel();
        main.setLayout(new GridLayout(3, 3));
        main.setSize(400, 350);
        main.setBounds(255, 175, 600, 400);

        // Button panel

        sub1.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub1);
        sub1.setBackground(Color.WHITE);
        originalColor = sub1.getBackground();
        sub1.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub1.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub1.setBackground(originalColor);
            }
        });

        sub2.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub2);
        sub2.setBackground(Color.WHITE);
        originalColor = sub2.getBackground();
        sub2.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub2.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub2.setBackground(originalColor);
            }
        });

        sub3.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub3);
        sub3.setBackground(Color.WHITE);
        originalColor = sub3.getBackground();
        sub3.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub3.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub3.setBackground(originalColor);
            }
        });

        sub4.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub4);
        sub4.setBackground(Color.WHITE);
        originalColor = sub4.getBackground();
        sub4.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub4.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub4.setBackground(originalColor);
            }
        });

        sub5.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub5);
        sub5.setBackground(Color.WHITE);
        originalColor = sub5.getBackground();
        sub5.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub5.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub5.setBackground(originalColor);
            }
        });

        sub6.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub6);
        sub6.setBackground(Color.WHITE);
        originalColor = sub6.getBackground();
        sub6.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub6.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub6.setBackground(originalColor);
            }
        });

        sub7.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub7);
        sub7.setBackground(Color.WHITE);
        originalColor = sub7.getBackground();
        sub7.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub7.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub7.setBackground(originalColor);
            }
        });

        sub8.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub8);
        sub8.setBackground(Color.WHITE);
        originalColor = sub8.getBackground();
        sub8.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub8.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub8.setBackground(originalColor);
            }
        });

        sub9.setFont(new Font("DialogInput", Font.BOLD, 15));
        main.add(sub9);
        sub9.setBackground(Color.WHITE);
        originalColor = sub9.getBackground();
        sub9.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                sub9.setBackground(new Color(160, 182, 45));
            }

            public void mouseExited(MouseEvent e) {
                sub9.setBackground(originalColor);
            }
        });

        sub1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Time Travel");
                ImageIcon Image11 = new ImageIcon("book11.jpg");
                ImageIcon Image12 = new ImageIcon("book12.jpg");
                ImageIcon Image13 = new ImageIcon("book13.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("TimeLine");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=timeline&crid=2X4DX2ZF629FJ&sprefix=timeli%2Caps%2C283&ref=nb_sb_ss_ts-doa-p_1_6"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Dragonfly");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=dragonfly+in+amber&crid=1QI0L9PRVXM2J&sprefix=drgonfly+%2Caps%2C312&ref=nb_sb_ss_sc_9_10"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Night Watch");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=night+watch+book&crid=2XLFHWRCBHRCS&sprefix=night+watch+boo%2Caps%2C384&ref=nb_sb_ss_ts-doa-p_1_15"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Adventure Stories");
                ImageIcon Image11 = new ImageIcon("book21.jpg");
                ImageIcon Image12 = new ImageIcon("book22.jpg");
                ImageIcon Image13 = new ImageIcon("book23.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Watership Down");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=water+down+book&crid=3K3SL8ET46R3T&sprefix=water+down+%2Caps%2C388&ref=nb_sb_ss_ts-doa-p_6_11"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Stranger");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+stranger&crid=45469KUNCKAK&sprefix=the+st%2Caps%2C362&ref=nb_sb_ss_ts-doa-p_6_6"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Holes");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=holes&crid=2PKW31PAFR6V7&sprefix=holes%2Caps%2C431&ref=nb_sb_ss_ts-doa-p_1_5"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("science Fiction");
                ImageIcon Image11 = new ImageIcon("book31.jpg");
                ImageIcon Image12 = new ImageIcon("book32.jpg");
                ImageIcon Image13 = new ImageIcon("book33.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Maze Runner");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+maze+runner&crid=3R78BGXMKTM6T&sprefix=the+maze%2Caps%2C296&ref=nb_sb_ss_ts-doa-p_1_8"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Giver");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+giver&crid=24O6OZU7DIKK7&sprefix=the+giver%2Caps%2C294&ref=nb_sb_noss_1"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Host");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+host&crid=123FUQY63WBC&sprefix=the+host%2Caps%2C293&ref=nb_sb_noss_1"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Love Stories");
                ImageIcon Image11 = new ImageIcon("book41.jpg");
                ImageIcon Image12 = new ImageIcon("book42.jpg");
                ImageIcon Image13 = new ImageIcon("book43.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Wuthering Heights");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=wuthering+heights&crid=4OJ9OR6JOZ0Z&sprefix=wuther%2Caps%2C287&ref=nb_sb_ss_ts-doa-p_2_6"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Notebook");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+notebook+book&crid=2KZG73PME6OR0&sprefix=the+notebook%2Caps%2C390&ref=nb_sb_ss_ts-doa-p_3_12"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Selection");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+selection+book+series&crid=1YGX8DHNJEL5W&sprefix=the+selection%2Caps%2C352&ref=nb_sb_ss_ts-doa-p_2_13"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Young Adult Fiction");
                ImageIcon Image11 = new ImageIcon("book51.jpg");
                ImageIcon Image12 = new ImageIcon("book52.jpg");
                ImageIcon Image13 = new ImageIcon("book53.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Eclipse");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=eclipse+book&crid=2JPTP973N06EV&sprefix=eclipse%2Caps%2C239&ref=nb_sb_ss_ts-doa-p_2_7"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Breark Dawn");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=breaking+dawn&crid=2FWEEOJFTJ7ME&sprefix=break%2Caps%2C427&ref=nb_sb_ss_ts-doa-p_1_5"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The book Thief");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+book+thief&crid=1LCBCURLPP1FR&sprefix=the+book+%2Caps%2C385&ref=nb_sb_ss_ts-doa-p_1_9"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Thrillers&Suspence");
                ImageIcon Image11 = new ImageIcon("book61.jpg");
                ImageIcon Image12 = new ImageIcon("book62.jpg");
                ImageIcon Image13 = new ImageIcon("book63.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Wife Between Us");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+wife+between+us&crid=1S9AOSXH09PV8&sprefix=the+wife%2Caps%2C320&ref=nb_sb_ss_ts-doa-p_1_8"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Circle");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+circle+book&crid=BWSXQTZSGIB8&sprefix=the+circle+boo%2Caps%2C257&ref=nb_sb_ss_ts-doa-p_1_14"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Into the Water");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=into+the+water+book&crid=JQ8BYUQHEJ33&sprefix=into+the+wa%2Caps%2C278&ref=nb_sb_ss_ts-doa-p_4_11"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Fantasy Fiction");
                ImageIcon Image11 = new ImageIcon("book71.jpg");
                ImageIcon Image12 = new ImageIcon("book72.jpg");
                ImageIcon Image13 = new ImageIcon("book73.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Lion");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+lion+the+witch+and+the+wardrobe+book&crid=KH3CVQNVN8D8&sprefix=the+lion+%2Caps%2C273&ref=nb_sb_ss_ts-doa-p_1_9"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Lightning Thief");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+lightning+thief&crid=3KCM5K8XSDA90&sprefix=the+li%2Caps%2C339&ref=nb_sb_ss_ts-doa-p_3_6"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Lord of the Rings");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+lord+of+the+rings&crid=2J9JTZLBMLF2Z&sprefix=the+lord+of+the+rings+%2Caps%2C319&ref=nb_sb_noss_2"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                photo1.setBackground(new Color(201, 145, 95));
                JPanel photo2 = new JPanel();
                photo2.setBackground(new Color(201, 145, 95));
                JPanel photo3 = new JPanel();
                photo3.setBackground(new Color(201, 145, 95));
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Romance");
                ImageIcon Image11 = new ImageIcon("book81.jpg");
                ImageIcon Image12 = new ImageIcon("book82.jpg");
                ImageIcon Image13 = new ImageIcon("book83.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Cider House");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+cider+house+rules+book&crid=818FQGSJOOWN&sprefix=the+cider%2Caps%2C339&ref=nb_sb_ss_ts-doa-p_1_9"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Mists of Avalon");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+mists+of+avalon&crid=2TLW9KXGQ811&sprefix=the+mists%2Caps%2C305&ref=nb_sb_ss_ts-doa-p_1_9"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("The Cruel Prince");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=the+cruel+prince&crid=110SI97OPG0IG&sprefix=the+cru%2Caps%2C315&ref=nb_sb_ss_ts-doa-p_1_7"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });
        sub9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // String subject ;
                JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(750, 700);
                bookFrame.setLayout(new GridLayout(4, 1));
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel name = new JPanel();
                name.setBackground(new Color(201, 145, 95));
                JLabel subject_Name = new JLabel("");
                subject_Name.setFont(new Font("Serif", Font.BOLD, 40));
                name.add(subject_Name);

                JPanel photo1 = new JPanel();
                JPanel photo2 = new JPanel();
                JPanel photo3 = new JPanel();
                photo1.setLayout(new BorderLayout());
                photo2.setLayout(new BorderLayout());
                photo3.setLayout(new BorderLayout());
                JLabel book_photo1 = new JLabel(" ");
                JLabel book_photo2 = new JLabel(" ");
                JLabel book_photo3 = new JLabel(" ");
                JPanel addInfo1 = new JPanel();
                addInfo1.setBackground(new Color(201, 145, 95));
                JPanel addInfo2 = new JPanel();
                addInfo2.setBackground(new Color(201, 145, 95));
                JPanel addInfo3 = new JPanel();
                addInfo3.setBackground(new Color(201, 145, 95));
                addInfo1.setLayout(new GridLayout(3, 1));
                addInfo2.setLayout(new GridLayout(3, 1));
                addInfo3.setLayout(new GridLayout(3, 1));
                JButton add1 = new JButton("Add to List");
                add1.setBackground(new Color(160, 182, 45));
                JButton add2 = new JButton("Add to List");
                add2.setBackground(new Color(160, 182, 45));
                JButton add3 = new JButton("Add to List");
                add3.setBackground(new Color(160, 182, 45));
                JButton info1 = new JButton("Info/Buy");
                info1.setBackground(new Color(160, 182, 45));
                JButton info2 = new JButton("Info/Buy");
                info2.setBackground(new Color(160, 182, 45));
                JButton info3 = new JButton("Info/Buy");
                info3.setBackground(new Color(160, 182, 45));
                JLabel addmessage1 = new JLabel("");
                JLabel addmessage2 = new JLabel("");
                JLabel addmessage3 = new JLabel("");
                addInfo1.add(addmessage1);
                addInfo1.add(add1);
                addInfo1.add(info1);
                addInfo2.add(addmessage2);
                addInfo2.add(add2);
                addInfo2.add(info2);
                addInfo3.add(addmessage3);
                addInfo3.add(add3);
                addInfo3.add(info3);
                photo1.add(book_photo1, BorderLayout.CENTER);
                photo1.add(addInfo1, BorderLayout.EAST);
                photo2.add(book_photo2, BorderLayout.CENTER);
                photo2.add(addInfo2, BorderLayout.EAST);
                photo3.add(book_photo3, BorderLayout.CENTER);
                photo3.add(addInfo3, BorderLayout.EAST);

                bookFrame.add(name);
                bookFrame.add(photo1);
                bookFrame.add(photo2);
                bookFrame.add(photo3);

                bookFrame.setVisible(true);

                subject_Name.setText("Dystopias");
                ImageIcon Image11 = new ImageIcon("book91.jpg");
                ImageIcon Image12 = new ImageIcon("book92.jpg");
                ImageIcon Image13 = new ImageIcon("book93.jpg");
                book_photo1.setIcon(Image11);
                book_photo2.setIcon(Image12);
                book_photo3.setIcon(Image13);
                book_photo1.setText(null);
                book_photo2.setText(null);
                book_photo3.setText(null);

                add1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Matched");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage1.setText("The book was added   ");
                    }
                });

                info1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=matched+book&crid=2IT8NIZA3OLJL&sprefix=matched%2Caps%2C319&ref=nb_sb_ss_ts-doa-p_4_7"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Delirium");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage2.setText("The book was added   ");
                    }
                });

                info2.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=delirium&crid=JMBL7MN1RJYP&sprefix=deli%2Caps%2C447&ref=nb_sb_ss_ts-doa-p_4_4"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

                add3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            output.writeUTF("Legend");
                        } catch (IOException ex) {
                            ex.getMessage();
                        }
                        addmessage3.setText("The book was added   ");
                    }
                });

                info3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI(
                                    "https://www.amazon.com/s?k=legend&crid=3O1LURNTVZLBM&sprefix=legend%2Caps%2C409&ref=nb_sb_ss_ts-doa-p_3_6"));
                        } catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();// printerror
                        }
                    }
                });

            }

        });

        // frame
        setTitle("Book Recommendation System");
        setSize(1100, 700);
        setLayout(null);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        bulidMenuBar();

        // background
        ImageIcon background_image = new ImageIcon("background.jpeg");
        Image img = background_image.getImage();
        Image temp_img = img.getScaledInstance(1100, 700, Image.SCALE_SMOOTH);
        background_image = new ImageIcon(temp_img);
        JLabel background = new JLabel("", background_image, JLabel.CENTER);

        background.add(main);
        background.add(header);
        background.setBounds(0, 0, 1100, 700);
        add(background);

        // pack();
        setVisible(true);
    }

    private void bulidMenuBar() {
        menuBar = new JMenuBar();
        bulidProgramMenu();
        bulidProfileMenu();
        menuBar.add(Program);
        menuBar.add(Profile);
        setJMenuBar(menuBar);

    }

    private void bulidProgramMenu() {
        exit = new JMenuItem("Exit");
        exit.setMnemonic(KeyEvent.VK_X);
        exit.addActionListener(new ExitListener());

        AboutUs = new JMenuItem("About Us");
        AboutUs.setMnemonic(KeyEvent.VK_F);
        AboutUs.addActionListener(new AboutUsListener());

        returnToMain = new JMenuItem("Return to Main Page");
        returnToMain.setMnemonic(KeyEvent.VK_B);
        returnToMain.addActionListener(new returnToMainListener());

        Program = new JMenu("Program");
        Program.setMnemonic(KeyEvent.VK_R);
        Program.add(exit);
        Program.add(AboutUs);
        Program.add(returnToMain);
    }

    private void bulidProfileMenu() {
        Account = new JMenuItem("Account");
        Account.setMnemonic(KeyEvent.VK_X);
        Account.addActionListener(new AccountListener());

        Profile = new JMenu("Profile");
        Profile.setMnemonic(KeyEvent.VK_R);
        Profile.add(Account);

    }

    private class ExitListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    private class AboutUsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            AboutUs s = new AboutUs();
            dispose();
        }
    }

    private class returnToMainListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            Book t = new Book();
            dispose();
        }
    }

    private class AccountListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {

            try {
                Account b = new Account();
            } catch (Exception ex) {
                Logger.getLogger(PopularSubject.class.getName()).log(Level.SEVERE, null, ex);
            }
            dispose();
        }
    }

    public static void main(String[] args) throws IOException {
        new PopularSubject();
    }

}
