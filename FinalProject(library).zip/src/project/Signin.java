package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;




public class Signin extends JFrame{
    
    String email ;
    String username;
    String password;
    String city;
    
    public Signin()throws IOException{
        
        //font
        Font g = new Font("Times New Roman" , Font.BOLD , 14);

        //header
        JPanel header = new JPanel();
        header.setBackground(new Color(0,0,0,80));
        header.setBounds(0,0,1100,100);
        JLabel name = new JLabel("My Account");
        name.setForeground(Color.WHITE);
        name.setBounds(200, 25, 1100, 50);
        name.setFont(new Font("Times New Roman" , Font.BOLD , 35));
        header.add(name);
        
        
        
        
        //main panel
        JPanel SigninPanel = new JPanel();
        SigninPanel.setLayout(null);
        SigninPanel.setSize(400,350);
        SigninPanel.setBackground(new Color(0,0, 0, 60));
        SigninPanel.setBounds(345, 175, 400, 400);
        
        JTextField field1= new JTextField(10);
        field1.setBounds(130,30,200,50);
        
        SigninPanel.add(field1);
        field1.getSelectedText();
        JLabel LABEL1 = new JLabel("Email");
        LABEL1.setForeground(Color.WHITE);
        LABEL1.setBounds(50, 30, 180, 50);
        LABEL1.setFont(g);
        SigninPanel.add(LABEL1);
        
        JTextField field2 = new JTextField(10);
        field2.setBounds(130,100,200,50);
        
        SigninPanel.add(field2);
        JLabel LABEL2 = new JLabel("User Name");
        LABEL2.setForeground(Color.WHITE);
        LABEL2.setBounds(40, 100, 180, 50);
        LABEL2.setFont(g);
        SigninPanel.add(LABEL2);
        
        
        JTextField field3 = new JTextField(10);
        field3.setBounds(130,170,200,50);
        
        SigninPanel.add(field3);
        JLabel LABEL3 = new JLabel("Password ");
        LABEL3.setForeground(Color.WHITE);
        LABEL3.setBounds(40, 170, 180, 50);
        LABEL3.setFont(g);
        SigninPanel.add(LABEL3);
        
        
        JTextField field4 = new JTextField(10);
        field4.setBounds(130,240,200,50);
        
        SigninPanel.add(field4);
        JLabel LABEL4 = new JLabel("City");
        LABEL4.setForeground(Color.WHITE);
        LABEL4.setBounds(60, 240, 180, 50);
        LABEL4.setFont(g);
        SigninPanel.add(LABEL4);
        
        JButton button1 = new JButton("Sign in");
        button1.setBounds(180,309, 100,50);
        button1.setBackground(new Color(160, 182,45));
        SigninPanel.add(button1);
           button1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                
                email = field1.getText();
                username = field2.getText();
                password = field3.getText();
                city = field4.getText();
                
                LoginWindow w = new LoginWindow(); 
                
                    FileWriter fw;
                    
                    try{
                        FileOutputStream file = new FileOutputStream("Info.dat");
                        DataOutputStream output = new DataOutputStream(file);
            
                        output.writeUTF("Email: "+email);
                        output.writeUTF("User Name: "+username);
                        output.writeUTF("Password: "+password);
                        output.writeUTF("The City: "+city);
            
                        output.flush();
                        output.close();
            
                    }catch(IOException ex){
                        ex.getMessage();
                    }
                try {
                    
                    PrintWriter pw = new PrintWriter("userInfo.txt");
                   
                    pw.println("Email:" + email);
                    pw.println("User Name: " + username);
                    pw.println("Password:" + password);
                    pw.println("The City: " + city);
                    pw.close(); 
                } catch (IOException ex) {
                    ex.getMessage();
                }
                    
            
         
                
            }
            });
        
        //frame
        setTitle("Book Recommendation System");
        setSize(1100,700);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        //background
        ImageIcon background_image = new ImageIcon("background.jpeg");
        Image img = background_image.getImage();
        Image temp_img = img.getScaledInstance(1100, 700, Image.SCALE_SMOOTH);
        background_image = new ImageIcon(temp_img);
        JLabel background = new JLabel("",background_image, JLabel.CENTER);
        
        background.add(header);
        background.add(SigninPanel);
        background.setBounds(0, 0, 1100, 700);
        add(background);
        
        
        
        setVisible(true);
        
        
    }
    public static void main(String[] args) throws IOException {
        new Signin();
    }


    
}
