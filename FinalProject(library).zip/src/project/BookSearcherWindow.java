package project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;





public class BookSearcherWindow extends JFrame {
    private JMenuBar menuBar;
    private JMenu Program;
    private JMenu Profile;
    private JMenuItem exit;
    private JMenuItem AboutUs;
    private JMenuItem returnToMain;
    private JMenuItem Account;
    
    private String[] books = {"timeline","dragonfly in amber" ," night watch","watership down","the stranger","holes","the maze runner","the giver"
        ,"the host", "wuthering heights","the notebook","the selection","eclipse", "breaking dawn","the book thief", "the wife between us","the circle",
        "into the water","the lion","the lightning thief","the lord of the rings","the cider house rules","the mists of avalon", "the cruel","matched"
        ,"delirium","legend"};
    
    public BookSearcherWindow()throws IOException, addException{
        
        
        
        //file
        FileOutputStream file = new FileOutputStream("favoirteBook.dat");
        DataOutputStream output = new DataOutputStream(file);
        //font
        Font f = new Font("Serif" , Font.BOLD , 35);
        Font g = new Font("Times New Roman" , Font.BOLD , 20);
        Font d = new Font("Times New Roman" , Font.BOLD , 16);
        
        //header
        JPanel heading1 = new JPanel();
        heading1.setBackground(new Color(0,0,0,80));
        heading1.setBounds(0,0,1100,100);
        JLabel name1 = new JLabel(" Your Personal Book Searcher!");
        name1.setForeground(Color.WHITE);
        name1.setBounds(200, 25, 1100, 50);
        name1.setFont(f);
        heading1.add(name1);
        
        //Search panel
        JPanel NorthPanel = new JPanel();
        NorthPanel.setLayout(null);
        NorthPanel.setSize(300,350);
        NorthPanel.setBackground(new Color(0,0, 0, 60));
        NorthPanel.setBounds(255, 175, 600, 450);
        
        JLabel label1 = new JLabel("Type the name of the book to search for it");
        label1.setForeground(Color.WHITE);
        label1.setFont(g);
        label1.setBounds(140,60,1000,15);
        NorthPanel.add(label1);
        
        JLabel label2 = new JLabel("Book name:");
        label2.setForeground(Color.WHITE);
        label2.setFont(new Font("Times New Roman" , Font.BOLD , 19));
        label2.setBounds(60,100,200,50);
        NorthPanel.add(label2);
        
        JTextField field1 = new JTextField(10);
        field1.setBounds(180,100,300,50);
        field1.setEditable(true);
        NorthPanel.add(field1);
        
      
        JButton search = new JButton("Search");
        search.setBounds(270, 180, 100, 50);
        search.setBackground (new Color(160, 182,45));
        search.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) {
                
            String bookName = field1.getText();
            JFrame bookFrame = new JFrame("Book Details");
                bookFrame.setSize(600,320);
                bookFrame.setLocationRelativeTo(null);
                bookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                bookFrame.setLayout(new BorderLayout());
                
                
                JPanel name = new JPanel();
                name.setBackground(new Color(201,145,95));
                JLabel book_Name = new JLabel(bookName);
                book_Name.setFont(new Font("Serif" , Font.BOLD , 40));
                name.add(book_Name,BorderLayout.CENTER);
                
                JPanel bigPane = new JPanel();
                JPanel photo = new JPanel();
                JLabel book_photo = new JLabel(" ");
                photo.setLayout(new BorderLayout());
                bigPane.setLayout(new BorderLayout());
                photo.add(book_photo , BorderLayout.CENTER);
                bigPane.add(photo , BorderLayout.CENTER);
                
                
                
                
                JPanel panelButton = new JPanel();
                panelButton.setBackground(new Color(201,145,95));
                JLabel addmessage = new JLabel("");
                JButton add = new JButton("Add to List");
                JButton info = new JButton("Info/Buy");
                panelButton.add(addmessage);
                panelButton.add(add);
                panelButton.add(info);
                
                
                bookFrame.add(name , BorderLayout.NORTH);
                bookFrame.add(bigPane , BorderLayout.CENTER);
                bookFrame.add(panelButton , BorderLayout.SOUTH);
                
                add.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                boolean found = false;
                try{
                for(int i =0;i<books.length;i++){
                if((field1.getText().equalsIgnoreCase(books[i]))){
                String bookName = field1.getText();
                found = true;
                try {
                output.writeUTF(bookName);
                }catch (IOException ex) {
                ex.getMessage();
                }
                addmessage.setText("The book was added");
                }
                }
                if(!found){
                throw new addException("This book is not available");
                }
                }
                catch(addException ex){
                JOptionPane.showMessageDialog(null, ex.getMessage());
                }
                }
                });
                /*add.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            throw new addException("This feature requires you to be a subscriber!");
                        } catch (addException ex) {
                            JOptionPane.showMessageDialog(null, ex.getMessage());
                        }
                    }
                });*/
                
                info.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try{
                            Desktop.getDesktop().browse(new URI("https://www.amazon.com/b?node=283155"));
                        }
                        catch (IOException | URISyntaxException ex) {
                            ex.printStackTrace();//printerror
                        }
                    }
                });
                
                
                bookFrame.setVisible(true);
                
             if(bookName.equalsIgnoreCase("TimeLine")){
                ImageIcon Image1 = new ImageIcon("book11.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
 
            }
            else if(bookName.equalsIgnoreCase("dragonfly in amber")){
                ImageIcon Image1 = new ImageIcon("book12.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
            }
            else if(bookName.equalsIgnoreCase("night watch")){
                ImageIcon Image1 = new ImageIcon("book13.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
              
            }
            else if(bookName.equalsIgnoreCase("watership down")){
                ImageIcon Image1 = new ImageIcon("book21.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("the stranger")){
                ImageIcon Image1 = new ImageIcon("book22.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
               
            }
            else if(bookName.equalsIgnoreCase("holes")){
                ImageIcon Image1 = new ImageIcon("book23.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("the maze runner")){
                ImageIcon Image1 = new ImageIcon("book31.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
             
            }
            else if(bookName.equalsIgnoreCase("The giver")){
                ImageIcon Image1 = new ImageIcon("book32.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The host")){
                ImageIcon Image1 = new ImageIcon("book33.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("wuthering heights")){
                ImageIcon Image1 = new ImageIcon("book41.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("the notebook")){
                ImageIcon Image1 = new ImageIcon("book42.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("the selection")){
                ImageIcon Image1 = new ImageIcon("book43.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("eclips")){
                ImageIcon Image1 = new ImageIcon("book51.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("breaking dawn")){
                ImageIcon Image1 = new ImageIcon("book52.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The book thief")){
                ImageIcon Image1 = new ImageIcon("book53.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The wife between us")){
                ImageIcon Image1 = new ImageIcon("book61.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The circle")){
                ImageIcon Image1 = new ImageIcon("book62.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("into the water")){
                ImageIcon Image1 = new ImageIcon("book63.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The lion")){
                ImageIcon Image1 = new ImageIcon("book71.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The lightning thief")){
                ImageIcon Image1 = new ImageIcon("book72.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("Thr lord of the rings")){
                ImageIcon Image1 = new ImageIcon("book73.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The cider house rules")){
                ImageIcon Image1 = new ImageIcon("book81.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The mists of avalon")){
                ImageIcon Image1 = new ImageIcon("book82.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("The cruel prince")){
                ImageIcon Image1 = new ImageIcon("book83.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("matched")){
                ImageIcon Image1 = new ImageIcon("book91.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("delirium")){
                ImageIcon Image1 = new ImageIcon("book92.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else if(bookName.equalsIgnoreCase("legend")){
                ImageIcon Image1 = new ImageIcon("book93.jpg");
                book_photo.setIcon(Image1);
                book_photo.setText(null);
                
            }
            else {
                book_photo.setIcon(null);
                book_photo.setText("         "
                        + "                  "
                        + "The book you entered is not available."
                        + "Please enter another book name ");
                
            }

       
            
            }
    });
        NorthPanel.add(search);
        
        JLabel label3 = new JLabel("Didn't find the book?");
        label3.setForeground(Color.WHITE);
        label3.setFont(d);
        label3.setBounds(135,310,200,50);
        NorthPanel.add(label3);
        
        JButton AddBook = new JButton("Add Book");
        AddBook.setBounds (130,350, 150,50);
        AddBook.setBackground (new Color(160, 182,45));
        AddBook.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) 
            {
                String input = JOptionPane.showInputDialog("please enter the book's name: ");
                if(input.length() > 0){
                    JOptionPane.showMessageDialog(null,"Thank you for your feedback we will work on adding the book as soon as possible");
                }
                else {
                    JOptionPane.showMessageDialog(null,"Please enter the book's name");
                    
                }
            }
            });
        
        NorthPanel.add(AddBook);
        
        JButton Recomend = new JButton("Recomend Book");
        Recomend.setBounds(360,350, 150,50);
        Recomend.setBackground(new Color(160, 182,45));
        NorthPanel.add(Recomend);
        
        Recomend.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new PopularSubject();
                } catch (IOException ex) {
                    ex.getMessage();
                }
                dispose();//to close previous frame
            }
        });
                
                
        
        //frame
        setTitle("Search for a Book");
        setSize(1100,700);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        bulidMenuBar();
        
        
        //Backround
        ImageIcon background_image = new ImageIcon("background.jpeg");
        Image img = background_image.getImage();
        Image temp_img = img.getScaledInstance(1100, 700, Image.SCALE_SMOOTH);
        background_image = new ImageIcon(temp_img);
        JLabel background = new JLabel("",background_image, JLabel.CENTER);
        
        background.add(heading1);
        background.add(NorthPanel);
        background.setBounds(0, 0, 1100, 700);
        add(background);
        
        //pack();
        setVisible(true);
        
    }
    
    private void bulidMenuBar()
        {
            menuBar = new JMenuBar();
            bulidProgramMenu();
            bulidProfileMenu();
            menuBar.add(Program);
            menuBar.add(Profile);
            setJMenuBar(menuBar);
            
        }
        
        private void bulidProgramMenu()
        {
            exit = new JMenuItem("Exit");
            exit.setMnemonic(KeyEvent.VK_X);
            exit.addActionListener(new ExitListener() );
            
            AboutUs = new JMenuItem("About Us");
            AboutUs.setMnemonic(KeyEvent.VK_F);
            AboutUs.addActionListener(new AboutUsListener() );
            
            returnToMain = new JMenuItem("Return to Main Page");
            returnToMain.setMnemonic(KeyEvent.VK_B);
            returnToMain.addActionListener(new returnToMainListener() );
            
            Program = new JMenu("Program");
            Program.setMnemonic(KeyEvent.VK_R);
            Program.add(exit);
            Program.add(AboutUs);
            Program.add(returnToMain);
        }
        
        private void bulidProfileMenu()
        {
            Account = new JMenuItem("Account");
            Account.setMnemonic(KeyEvent.VK_X);
            Account.addActionListener(new AccountListener() );
            
            
            
            Profile = new JMenu("Profile");
            Profile.setMnemonic(KeyEvent.VK_R);
            Profile.add(Account);
         
        }
        private class ExitListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }
        
        private class AboutUsListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                    AboutUs s = new AboutUs();
                    dispose();
            }
        }
      
        private class returnToMainListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
           
                    Book t = new Book();
                    dispose();
            }
        }
        
           private class AccountListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
           
                try {
                    Account b = new Account();
                } catch (Exception ex) {
                    Logger.getLogger(BookSearcherWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
                dispose();
            }
        }
     public static void main(String[] args) throws IOException, addException {
        new BookSearcherWindow();
    }
 
    
}
