package project;


import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;



public class Book extends JFrame {
    
    private JMenuBar menuBar;
    private JMenu Program;
    private JMenuItem exit;
    private JMenuItem AboutUs;
    
    
    Book(){
        
        //font
        Font f = new Font("Serif" , Font.BOLD , 35);
        Font g = new Font("Times New Roman" , Font.BOLD , 20);
        
        //header
        JPanel heading;
        heading = new JPanel();
        heading.setBackground(new Color(0,0,0,80));
        heading.setBounds(0,0,1100,100);
        JLabel name = new JLabel("Book Recommendation System");
        name.setForeground(Color.WHITE);
        name.setBounds(200, 25, 1100, 50);
        name.setFont(f);
        heading.add(name);
         
        //login panel
        JPanel start = new JPanel();
        start.setLayout(null);
        start.setSize(400,350);
        start.setBackground(new Color(0,0, 0, 60));
        start.setBounds(245, 175, 600, 350);
        
        
        
        JLabel LABEL = new JLabel("!Welcome to Your Personal library!");
        LABEL.setForeground(Color.WHITE);
        LABEL.setBounds(150, 80, 550, 50);
        LABEL.setFont(new Font("Times New Roman" , Font.BOLD , 25));
        start.add(LABEL);
      
        JLabel LABEL1 = new JLabel("This program helps you finding your next book based on");
        LABEL1.setForeground(Color.WHITE);
        LABEL1.setBounds(80, 130, 550, 50);
        LABEL1.setFont(g);
        start.add(LABEL1);
        
        JLabel LABEL4 = new JLabel("        your interests and prefrence ");
        LABEL4.setForeground(Color.WHITE);
        LABEL4.setBounds(160, 160, 550, 50);
        LABEL4.setFont(g);
        start.add(LABEL4);
        
      
        
        JButton button = new JButton("Start");
        button.setBounds (285,250, 100,50);
        button.setBackground (new Color(160, 182,45));
        button.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                LoginWindow w = new LoginWindow();
            }
            });
        start.add(button) ;
        
       
        //frame
        setTitle("Book Recommendation System");
        setSize(1100,700);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        bulidMenuBar();
        //background
        ImageIcon background_image = new ImageIcon("background.jpeg");
        Image img = background_image.getImage();
        Image temp_img = img.getScaledInstance(1100, 700, Image.SCALE_SMOOTH);
        background_image = new ImageIcon(temp_img);
        JLabel background = new JLabel("",background_image, JLabel.CENTER);
        
        background.add(start);
        background.add(heading);
        background.setBounds(0, 0, 1100, 700);
        add(background);
        setVisible(true);
        
    }
    
     private void bulidMenuBar()
        {
            menuBar = new JMenuBar();
            bulidProgramMenu();
            menuBar.add(Program);
            setJMenuBar(menuBar);
            
        }
        
        private void bulidProgramMenu()
        {
            exit = new JMenuItem("Exit");
            exit.setMnemonic(KeyEvent.VK_X);
            exit.addActionListener(new ExitListener() );
            
            AboutUs = new JMenuItem("About Us");
            AboutUs.setMnemonic(KeyEvent.VK_F);
            AboutUs.addActionListener(new AboutUsListener() );
            
            Program = new JMenu("Program");
            Program.setMnemonic(KeyEvent.VK_B);
            Program.add(exit);
            Program.add(AboutUs);
        }
        
        
        private class ExitListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }
        
        private class AboutUsListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                try {
                    AboutUs s = new AboutUs();
                } catch (Exception ex) {
                    Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                }
                dispose();
            }
        }
    

   
    public static void main(String[] args) {
        new Book();
    }
    
        }