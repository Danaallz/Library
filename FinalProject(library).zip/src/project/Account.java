
package project;


import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Account extends JFrame{
    
    
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JLabel label4;
    private JLabel label5;
    private JLabel label6;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;
    private JTextField text1;
    private JMenuBar menuBar;
    private JMenu Program;
    private JMenu Profile;
    private JMenuItem exit;
    private JMenuItem AboutUs;
    private JMenuItem returnToMain;
    private JMenuItem Account;
    private JComboBox bookBox;
    private JPanel BookPanel;
    private JPanel selectedCoffeePanel;
    private JTextField selectedBook; 
    
    private String[] book = new String[20];
    
    //private String[] Info = new String[5];
    
    File myFile = new File("nextRead.txt");
    Scanner inputFile = new Scanner(myFile);
    
    /*File File = new File("userInfo.txt");
    Scanner input = new Scanner(File);*/
    
    
    public Account() throws Exception{
        
        int i = 0;
        while(inputFile.hasNext()){
            book[i] = inputFile.nextLine();
            i++;
        }
        
        /*int j = 0;
        while(input.hasNext()){
            Info[j] = input.nextLine();
            j++;
        }*/
        
        setTitle("Book Recommendation System");
        setSize(1100,400);
        setLocation(100, 60);
        setLayout(new GridLayout(1, 4));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setBackground(new Color(201,145,95));
       
        panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBackground(new Color(201,145,95));
        
        label1 = new JLabel("USER INFORMATION");
        label1.setBounds(100, 00, 900, 50);
        label1.setFont(new Font("Times New Roman" , Font.BOLD , 19));
        
        label4 = new JLabel("User Name:");
        label4.setBounds(70, 100, 100, 50);
        label4.setFont(new Font("Times New Roman" , Font.BOLD , 14));
        
        
        label5 = new JLabel("Password: ");
        label5.setFont(new Font("Times New Roman" , Font.BOLD , 14));
        label5.setBounds(80, 170, 100, 50);
        
        
        JPasswordField password = new JPasswordField("Enter password...",20);
        password.setBounds(150, 170,150,50);
        password.setEditable(false);
        
        JTextField username = new JTextField("username ",10);
        username.setBounds(150, 100, 150, 50);
        username.setEditable(false);
        //username.setText(Info[1]);
        
        JButton button1 = new JButton("Edit Information");
        button1.setBackground (new Color(160, 182,45));
        button1.setBounds(150, 250, 150, 50);
        button1.setBackground (new Color(160, 182,45));
        button1.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e) 
            {
                    JOptionPane.showMessageDialog(null,"Sumbmit a request to change personal information is sucssesful ! We will allow you to update information soon");
                    
                }
            }
            );
        
        
        panel1.add(label1);
        panel1.add(label4);
        panel1.add(username);
        panel1.add(label5);
        panel1.add(password);
        panel1.add(button1);
        
        panel2 = new JPanel();
        panel2.setBackground(new Color(201,145,95));
        label2 = new JLabel("");
        ImageIcon user = new ImageIcon("profile.gif");
        label2.setIcon(user);
        label2.setText(null);
        panel2.add(label2);
        
        panel3 = new JPanel();
        panel3.setLayout(null);
        panel3.setBackground(new Color(201,145,95));
        label3 = new JLabel("Your next reading");
        label3.setBounds(110, 50, 300, 50);
        label3.setFont(new Font("Times New Roman" , Font.BOLD , 19));
        panel3.add(label3);
       
        //Create a panel to hold the combo box
             
               // Create the combo box.
               bookBox = new JComboBox(book);
               bookBox.setBounds(90, 100, 200, 50);
               // Register an action listener.
               bookBox.addActionListener(new ComboBoxListener());
               // Add the combo box to the panel.
               panel3.add(bookBox);
        label6 = new JLabel("You selected:");
        label6.setFont(new Font("Times New Roman" , Font.BOLD , 14));
        label6.setBounds(6, 170, 100, 50);
        // Create the uneditable text field.
        selectedBook = new JTextField(10);
        selectedBook.setBounds(90, 170, 200, 40);
        selectedBook.setEditable(false);
        // Add the label and text field to the panel.
        panel3.add(label6);
        panel3.add(selectedBook);
        
            
        bulidMenuBar();
        add(panel3);
        add(panel1);
        add(panel2);
        
        //add favorite book is list
        
        
        
        //pack();
        setVisible(true);
        
    }
    private void bulidMenuBar()
        {
            menuBar = new JMenuBar();
            bulidProgramMenu();
            menuBar.add(Program);
            setJMenuBar(menuBar);
            
        }
        
        private void bulidProgramMenu()
        {
            exit = new JMenuItem("Exit");
            exit.setMnemonic(KeyEvent.VK_X);
            exit.addActionListener(new ExitListener() );
            
            AboutUs = new JMenuItem("About Us");
            AboutUs.setMnemonic(KeyEvent.VK_F);
            AboutUs.addActionListener(new AboutUsListener() );
            
            returnToMain = new JMenuItem("Return to Main Page");
            returnToMain.setMnemonic(KeyEvent.VK_B);
            returnToMain.addActionListener(new returnToMainListener() );
            
            Program = new JMenu("Program");
            Program.setMnemonic(KeyEvent.VK_R);
            Program.add(exit);
            Program.add(AboutUs);
            Program.add(returnToMain);
        }
        
        private class ExitListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }
        
        private class AboutUsListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                    AboutUs s = new AboutUs();
                    dispose();
            }
        }
      
        private class returnToMainListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
           
                    Book t = new Book();
                    dispose();
            }
        }
        
        
         private class ComboBoxListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                // Get the selected Book.
                String selection = (String) bookBox.getSelectedItem();
                selectedBook.setText(selection);
            }
            
         }
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        new Account();
    }
    
}
