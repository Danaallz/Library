package project;


import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;



public class AboutUs extends JFrame {
    
    private final int LABEL_W = 1100;
    private final int LABEL_H = 600;
    
    private JMenuBar menuBar;
    private JMenu Program;
    private JMenu Profile;
    private JMenuItem exit;
    private JMenuItem returnToMain;
    private JMenuItem Account;
    
    
    AboutUs(){
        
        //font
        Font f = new Font("Serif" , Font.BOLD , 35);
        Font g = new Font("Times New Roman" , Font.BOLD , 20);
        
        //header
        JPanel heading;
        heading = new JPanel();
        heading.setBackground(new Color(0,0,0,80));
        heading.setBounds(0,0,1100,100);
        JLabel name = new JLabel("Book Recommendation System");
        name.setForeground(Color.WHITE);
        name.setBounds(200, 25, 1100, 50);
        name.setFont(f);
        heading.add(name);
         
        //login panel
        JPanel start = new JPanel();
        start.setLayout(null);
        start.setSize(400,350);
        start.setBackground(new Color(0,0, 0, 60));
        start.setBounds(8, 100, 1100, 650);
        
        
        
        JTextArea LABEL = new JTextArea("Welcome to our Book Recommendation System, where literary exploration meets personalized curation."
                + "At the heart of our platform is a passion for connecting readers with the perfect        book for "
                + "every mood, interest, and moment. We understand that each reader is unique, "
                + "and   so is their reading journey. Our team of avid bibliophiles and tech enthusiasts has crafted a "
                + "  dynamic system that blends the art of literature with cutting-edge technology.Whether you're a "
                + "seasoned bookworm or just embarking on your reading adventure, our platform is designed to intuitively understand your preferences "
                + "and recommend books that resonate with your       individual tastes. Join us on this literary odyssey as "
                + "we celebrate the diverse world of books,    fostering a community of readers who share a love for discovering new stories and authors.    Embrace the joy of reading with us, "
                + "where every recommendation is a step towards a new,      captivating literary experience." ,50,50);
        
        LABEL.setLineWrap(true);
        LABEL.setForeground(Color.black);
        LABEL.setBounds(30, 10, 1020, 400);
        LABEL.setFont(new Font("Serif" , Font.BOLD , 25));
        start.add(LABEL);
      
        
        
        JButton button = new JButton("Start");
        button.setBounds (285,250, 100,50);
        button.setBackground (new Color(160, 182,45));
        start.add(button) ;
        
       
        //frame
        setTitle("Book Recommendation System");
        setSize(1100,700);
        setLayout(null);
        setLocationRelativeTo(null);
       
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        bulidMenuBar();
        //background
        ImageIcon background_image = new ImageIcon("background.jpeg");
        Image img = background_image.getImage();
        Image temp_img = img.getScaledInstance(1100, 700, Image.SCALE_SMOOTH);
        background_image = new ImageIcon(temp_img);
        JLabel background = new JLabel("",background_image, JLabel.CENTER);
        
        background.add(start);
        background.add(heading);
        background.setBounds(0, 0, 1100, 700);
        add(background);
        setVisible(true);
        
    }
      
    private void bulidMenuBar()
        {
            menuBar = new JMenuBar();
            bulidProgramMenu();
            bulidProfileMenu();
            menuBar.add(Program);
            menuBar.add(Profile);
            setJMenuBar(menuBar);
            
        }
        
        private void bulidProgramMenu()
        {
            exit = new JMenuItem("Exit");
            exit.setMnemonic(KeyEvent.VK_X);
            exit.addActionListener(new ExitListener() );
            
            returnToMain = new JMenuItem("Return to Main Page");
            returnToMain.setMnemonic(KeyEvent.VK_B);
            returnToMain.addActionListener(new returnToMainListener() );
            
            Program = new JMenu("Program");
            Program.setMnemonic(KeyEvent.VK_R);
            Program.add(exit);
            Program.add(returnToMain);
        }
        
        private void bulidProfileMenu()
        {
            Account = new JMenuItem("Account");
            Account.setMnemonic(KeyEvent.VK_X);
            Account.addActionListener(new AccountListener() );
            
            
            
            Profile = new JMenu("Profile");
            Profile.setMnemonic(KeyEvent.VK_R);
            Profile.add(Account);
         
        }
        private class ExitListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }
      
        private class returnToMainListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
           
                    Book t = new Book();
                    dispose();
            }
        }
        
           private class AccountListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
           
                try {
                    Account b = new Account();
                } catch (Exception ex) {
                    ex.getMessage();
                }
                dispose();
            }
        }
   
    public static void main(String[] args) {
        new AboutUs();
    }
    
        }